1.火曜-8-真夏の果実.zipをunzip
2.python3 -m venv venv で仮想環境を立ち上げて、venvをアクティベートする
3.unzipしてできたフォルダの中にある、main.pyをターミナル上で python main.pyを実行

